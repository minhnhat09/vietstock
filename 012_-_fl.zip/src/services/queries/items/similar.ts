export const getSimilarItems = async (itemId: string) => {};
