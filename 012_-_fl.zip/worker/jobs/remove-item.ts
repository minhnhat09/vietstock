import type { Client } from '../types';

export const removeItem = async () => {};
